# du
metric= (Predicted -measured/measured)*100

Servicepoints without significant outages ( if the value is more than 100 then it can be considered as significant or heavy 
outage)


Service points without significant outage

<img width="360" alt="image" src="https://user-images.githubusercontent.com/93844635/205510705-cade80f3-e5de-47a8-81f4-cd0e57369646.png">
<img width="371" alt="image" src="https://user-images.githubusercontent.com/93844635/205510798-ac132bb0-509e-487e-9061-ed86f6208669.png">
Inference- For dates 11 and 12,Here I could say the measured low was still higher than the predicted load by looking at the plot.As these were initial days of winterstorm, there was no problem with outages and people's measured energy usage was not much higher than energy usage in later days.

<img width="352" alt="image" src="https://user-images.githubusercontent.com/93844635/205511206-ca593a3a-f471-4b6a-a232-340fab02908b.png">
<img width="358" alt="image" src="https://user-images.githubusercontent.com/93844635/205511236-8dbcbbaa-8d7c-4768-8972-3d5b524ea2a5.png">
For dates 13, 14
Inference- If you could see the plots are more blue than previous ones, which says that the measured load was higher than predicted load compared to 11 and 12.
I could say 13 and 14 were days winter storm started to get severe and hence more measured energy compared to the days 13 and 14

<img width="383" alt="image" src="https://user-images.githubusercontent.com/93844635/205511634-2774f188-aca6-42cc-9b52-d663d9d07452.png">

Inference- For date 15, the measured energy should be higher than 13 and 14, so it should be more dark blue, but if you see the plot, you can see some whites and lights blue. This infers that some zipcodes experienced half outages or light outages, but not severe

<img width="365" alt="image" src="https://user-images.githubusercontent.com/93844635/205511724-739e0a75-d09a-4e58-82dc-0961a8138e7e.png">
<img width="379" alt="image" src="https://user-images.githubusercontent.com/93844635/205511737-7112982c-5b54-4ddd-acf4-f9e61b9b42c2.png">

Inference- For dates 16 and 17, the few parts of orange and red tells us that there was outages at certain zipcodes because the measured load was less than predicted load

<img width="362" alt="image" src="https://user-images.githubusercontent.com/93844635/205511865-1a65291c-14b3-4190-a2f0-43119e467916.png">
<img width="358" alt="image" src="https://user-images.githubusercontent.com/93844635/205511885-a00a16d6-ad05-48f1-a978-e8e015ca5ecc.png">

Inference- Dates 18 and 19 is where the things were going back normal and winterstorm effect has too been reduced, 18 and 19 shows a graduate shifting from red,orange color to blue in few zipcodes, which infers than outages in few service points were being restored





Service points with significant outages

So almost all of the heavy and full outages happened starting from date 15 and went on till 19

<img width="452" alt="image" src="https://user-images.githubusercontent.com/93844635/205512514-8df9d970-5bb4-431d-ad34-c792445c960f.png">
Almost all of the zipcodes the predicted load is higher than the measured load by looking at majority of orange and green zipcodes which infers than the zipcodes have experienced outages

<img width="407" alt="image" src="https://user-images.githubusercontent.com/93844635/205512625-cdd1a140-2942-4893-9207-f28c0d229436.png">
<img width="414" alt="image" src="https://user-images.githubusercontent.com/93844635/205512629-ac2b9ffa-b63c-441a-a272-bec6a2045191.png">

For dates 16 and 17 almost all of the zipcodes has full outages the predicted load was higher than 100% than measured load

<img width="425" alt="image" src="https://user-images.githubusercontent.com/93844635/205512708-8aeeb005-ae96-4c65-bb2f-3fb6f65d4245.png">
<img width="397" alt="image" src="https://user-images.githubusercontent.com/93844635/205512751-9e53bd38-a3db-4f51-a5ca-ff5764ffd74e.png">

Dates 18 and 19 saw a decrease in number of full outages in zipcodes, but still there were light outages as you see can see majority of zipcodes are in light orange and pale blue state
